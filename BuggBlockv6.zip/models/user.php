<?php
namespace models;
class user extends conexion{
    private $id_user;
    private $user;
    private $pass;
    private $role;
    private $select_user;

    function __construct($user, $pass){
        parent::__construct();
        $this->user = $user;
        $this->pass = $pass;
        $this->select_user = $this->conn->prepare("SELECT * FROM users WHERE username = :nombre AND password = :contra");
    }

    public function existUser_db(){
        $this->select_user->execute([':nombre' => $this->user, ':contra' => $this->pass]);
        return $this->select_user->rowCount();
    }

    public function getUser_db(){
        $this->select_user->execute([':nombre' => $this->user, ':contra' => $this->pass]);
        $datos = $this->select_user->fetch();
        $this->role = $datos['rol'];
        $this->id_user = $datos['id'];
        return $datos;
    }

    public function getRole(){ return $this->role; }
    public function getUser(){ return $this->user; }
    public function getPass(){ return $this->pass; }
    public function getId(){ return $this->id_user; }
}
?>