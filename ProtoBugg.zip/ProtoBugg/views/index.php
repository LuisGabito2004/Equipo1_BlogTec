<?php
    require_once("../autoload.php");
    session_start();
	use models\publicaciones;
    $publicacion = new publicaciones();
	$posts = $publicacion->getpublicaciones();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<!-- basic -->

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">

<!-- site metas -->
<title>BuggBlock</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">	

<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">

<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">

<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets --> 
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

</head>

<!-- body -->
<body>
	<div class="header_main">
		<div class="container">
			<div class="logo"><a href="#"><img src="images/LogoInicio.png"></a></div>
		</div>
	</div>
	</div>
	<div class="header">
		<div class="container">

        <!--  header inner -->
            <div class="col-sm-12">
                 
                 <div class="menu-area">
                    <nav class="navbar navbar-expand-lg ">

                        <!-- <a class="navbar-brand" href="#">Menu</a> -->
						<button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                       	<i class="fa fa-bars"></i>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                            	<li class="nav-item active"><a class="nav-link" href="#">Inicio<span class="sr-only">(current)</span></a></li>
								<!-- PHP: Cambion de interfaz segun la sesion -->
								<?php if(!isset($_SESSION["rol"])){ ?>

								<li class="nav-item"><a class="nav-link" href="login.php">Iniciar sesion</a></li>

								<?php } else {?>

								<li class="nav-item"><a class="nav-link" href="administrador.php">Administrador</a></li>
								<li class="nav-item"><a class="nav-link" href="../controlls/cerrarSesion.php">Cerrar sesion</a></li>

								<?php } ?>
								<!-- Fin de PHP -->
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div> 
    </div>
    <!-- end header end -->    

    <!--banner start -->
    <div class="banner-main">
    	<div class="container">
           <div id="main_slider" class="carousel slide" data-ride="carousel">  

           <!-- The slideshow -->
            <div class="carousel-inner">
                <div class="carousel-item active">
    		    <div class="titlepage-h1">
    	        <h1 class="bnner_title">Bienvenido<br>
    	        <span style="color: #10b5fa">A Este Espacio de Confianza Tecnica</span></h1>
    	        <p class="long_text">Un blogg donde expertos prueban y dan su opinion sobre la tecnologia </p>
    		    </div>
        </div>
    <div class="carousel-item">
    		<div class="titlepage-h1">
    	       <h1 class="bnner_title">Regalan RTX3050<br>
    	       <span style="color: #10b5fa">ES INEDITO DE PARTE DE NVIDIA</span></h1>
    	       <p class="long_text">Deebido a la llegada de la grafica 4000 series, las RTX 3000 series estan que vuelan </p>
    		</div>
        </div>
    <div class="carousel-item">
    		<div class="titlepage-h1">
    	       <h1 class="bnner_title">Fallas Comunes de Nvida<br>
    	       <span style="color: #10b5fa">En Graficas de la Serie 4000</span></h1>
    	       <p class="long_text">Las nuevas graficas estan que flipan, pero han llegado con un defecto, quedate a averiguarlo </p>
    		</div>
    </div>
  </div> 
         <a class="carousel-control-prev" href="#main_slider" role="button" data-slide="prev">
                <i class="fa fa-angle-left"></i>
            </a>
        <a class="carousel-control-next" href="#main_slider" role="button" data-slide="prev">
                <i class="fa fa-angle-right"></i>
            </a>
    </div>
</div>
</div>
<!--banner end -->

    <!--services start -->
    <div class="services_main">
    	<div class="container">
    		<div class="creative_taital">
    			<h1 class="creative_text">El Blogg de un Estudiante</h1>
    			<p style="color: #050000; text-align: center;">Esta es una pagina tipo blogger personal sobre nuestra opinion en algunas tecnologia que hemos problado o quremos probar, aqui podras tomar en cuenta opiniones sobre productos por si en dado caso tiene alguna duda en comprar algun tipo de estas tecnologias modernas</p>
    		</div>
    		    <div class="section_service_2">
    		    	<h1 class="service_text">Publicaciones</h1>
    		    </div>
		</div>
		<!-- PHP: Publicaciones -->
		<?php foreach ($posts as $post) { ?>
		<section class="form-main">
			<div class="form-content">
				<div class="box">
					<h4><?php echo $post['titulo'];?></h4>
					<h5><?php echo $post['contenido'];?></h5>
					<h6><?php echo $post['fecha_creacion'];?></h6>
				</div>
			</div>
		</section>
		<?php } ?>
	</div>
	
    <!--services end -->

    <!--quote_section start -->
    <div class="quote_section">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-6">
    				<h1 class="quote_text">Universidad De Colima</h1>
    				<p class="loan_text"> Ingenieria en software 1D <br>Facultad de Ingenieria Electromecanica</p>
    			</div>
    		</div>
    	</div>
    </div>
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>