<?php
namespace controlls;
require_once('../autoload.php');
use models\controller;
session_start();
session_destroy();
controller::gotoview('index.php');
?>