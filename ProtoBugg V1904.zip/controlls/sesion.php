<?php
namespace controlls;
require_once("../autoload.php");
use models\user;
session_start();
if(isset($_POST["rol"])){ header("location:../views/index.php"); }

$user = new user($_POST['username'], $_POST['password']);

if($user->existUser_db() > 0){
    $_SESSION['rol'] = 'admin';
    header("location:../views/administrador.php");
} else{
    header("location:../views/login.php");
}

?>