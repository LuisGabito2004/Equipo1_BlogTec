<?php
namespace models;
use PDO;
class publicaciones extends conexion{
    private $fecha_creacion;
    private $strtitulo;
    private $strcontenido;
    private $fecha_edicion;

    public function __construct(){
        parent::__construct();
    }
    public function Insertar(string $fecha_creacion, string $titulo, string $contenido){
        $this->fecha_creacion = $fecha_creacion;
        $this->strtitulo = $titulo;
        $this->strcontenido = $contenido;

        $sql="INSERT INTO publicaciones(fecha_creacion,titulo,contenido) VALUES(?,?,?)";
        $insert= $this->conn->prepare($sql);
        $arrData= array($this->fecha_creacion,$this->strtitulo,$this->strcontenido);
        $resInsert = $insert->execute($arrData);
        $idInsert = $this->conn->lastInsertId();
        return $idInsert;
    }
    public function getpublicaciones(){
        $sql="SELECT * FROM publicaciones";
        $execute = $this->conn->query($sql);
        $request = $execute->fetchall(PDO::FETCH_ASSOC);
        return $request;
    }
    public  function updatepublicaciones(int $id, string $titulo, string $contenido, string $fecha_edicion){
        $this->fecha_edicion = $fecha_edicion;
        $this->strtitulo = $titulo;
        $this->strcontenido = $contenido;
        $sql="UPDATE publicaciones SET fecha_edicion=?,titulo=?,contenido=? WHERE id_publicaciones=$id";
        $update= $this->conn->prepare($sql);
        $arrdatos= array($this->fecha_edicion,$this->strtitulo,$this->strcontenido);
        $resexecute = $update->execute($arrdatos);
        return $resexecute;
    }
    public function deletepublicaciones(int $id){
        $sql="DELETE FROM publicaciones WHERE id_publicaciones=?";
        $arrwhere =array($id);
        $delete= $this->conn->prepare($sql);
        $del = $delete->execute($arrwhere);
        return $del;
    }
}
?>