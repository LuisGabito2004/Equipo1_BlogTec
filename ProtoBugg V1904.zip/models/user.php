<?php
namespace models;
class user extends conexion{
    private $user;
    private $pass;
    private $select_user;

    function __construct($user, $pass){
        parent::__construct();
        $this->user = $user;
        $this->pass = $pass;
        $this->select_user = $this->conn->prepare("SELECT * FROM users WHERE username = :nombre AND password = :contra");
    }

    public function existUser_db(){
        $this->select_user->execute([':nombre' => $this->user, ':contra' => $this->pass]);
        return $this->select_user->rowCount();
    }
}
?>