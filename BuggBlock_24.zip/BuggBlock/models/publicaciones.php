<?php
namespace models;
use PDO;
class publicaciones extends conexion{
    private $fecha_creacion;
    private $strtitulo;
    private $strcontenido;
    private $fecha_edicion;
    private $id_user;

    public function __construct(){
        parent::__construct();
    }

    public function Insertar(string $fecha_creacion, string $titulo, string $contenido, int $id_user){
        $this->fecha_creacion = $fecha_creacion;
        $this->strtitulo = $titulo;
        $this->strcontenido = $contenido;
        $this->id_user = $id_user;

        $sql="INSERT INTO publicaciones(fecha_creacion,titulo,contenido,id_user) VALUES(?,?,?,?)";
        $insert= $this->conn->prepare($sql);
        $arrData= array($this->fecha_creacion,$this->strtitulo,$this->strcontenido, $this->id_user);
        $resInsert = $insert->execute($arrData);
        $idInsert = $this->conn->lastInsertId();
        return $idInsert;
    }

    public function getpublicaciones(){
        $sql="SELECT * FROM publicaciones ORDER BY fecha_creacion DESC";
        $execute = $this->conn->query($sql);
        $request = $execute->fetchall(PDO::FETCH_ASSOC);
        return $request;
    }
    
    public function getPublicacionesWithPublisher(){
        $sql = "SELECT p.id_publicaciones, p.titulo, p.fecha_creacion, p.fecha_edicion, u.username
        FROM publicaciones p
        INNER JOIN users u
        ON p.id_user = u.id
        ORDER BY p.fecha_creacion DESC";
        $execute = $this->conn->query($sql);
        $request = $execute->fetchall(PDO::FETCH_ASSOC);
        return $request;
    }

    public function getpublicacionesbyautor($id_user){
        $sql = "SELECT * FROM publicaciones WHERE id_user = $id_user";
        $execute = $this->conn->query($sql);
        $request = $execute->fetchall(PDO::FETCH_ASSOC);
        return $request;
    }

    public function getpublicacionById($id){
        $sql="SELECT * FROM publicaciones WHERE id_publicaciones = $id";
        $execute = $this->conn->query($sql);
        $request = $execute->fetch();
        return $request;
    }

    public  function updatepublicaciones(int $id, string $titulo, string $contenido, string $fecha_edicion){
        $this->fecha_edicion = $fecha_edicion;
        $this->strtitulo = $titulo;
        $this->strcontenido = $contenido;
        $sql="UPDATE publicaciones SET fecha_edicion=?,titulo=?,contenido=? WHERE id_publicaciones=$id";
        $update= $this->conn->prepare($sql);
        $arrdatos= array($this->fecha_edicion,$this->strtitulo,$this->strcontenido);
        $resexecute = $update->execute($arrdatos);
        return $resexecute;
    }

    public function deletepublicaciones(int $id){
        $sql="DELETE FROM publicaciones WHERE id_publicaciones=?";
        $arrwhere =array($id);
        $delete= $this->conn->prepare($sql);
        $del = $delete->execute($arrwhere);
        return $del;
    }
}
?>