<?php
namespace models;
class controller{
    static function gotoview($file){
        header('location:../views/' . $file);
    }
}
?>