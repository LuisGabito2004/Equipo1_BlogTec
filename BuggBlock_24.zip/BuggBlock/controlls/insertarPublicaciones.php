<?php
    session_start();
    if(!isset($_SESSION["rol"])){ header("location:index.php"); }
    require_once("../autoload.php");
    use models\publicaciones;
    $publicacion = new publicaciones();
    $today = date("Y-m-d H:i:s");
    if(!isset($_POST['titulo']) or !isset($_POST['contenido'])){
        header("location:../views/administrador-Editor.php");
    } else {
        $publicacion->Insertar($today, $_POST['titulo'], $_POST['contenido'], $_SESSION['id_user']);
        header("location:../views/administrador.php");
    }
?>