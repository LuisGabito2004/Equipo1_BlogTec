<?php
    namespace controlls;
    require_once("../autoload.php");
    use models\publicaciones;
    $objpublicaciones = new publicaciones();
    $today = date("Y-m-d H:i:s");
    $idinsert = $objpublicaciones->updatepublicaciones($_POST['id'],$_POST['titulo'],$_POST['contenido'],$today);
    header("location:../views/administrador.php");
?>